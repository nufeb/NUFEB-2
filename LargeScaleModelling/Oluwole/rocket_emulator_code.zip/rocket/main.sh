#!/bin/bash
#SBATCH -A tcnufeb
#
# SLURM defaults to the directory you were working in when you submitted the job.
#Output files are also put in this directory. To set a different working directory add:
#SBATCH --workdir=/mnt/storage/nobackup/noo11/Andrew/inputnum/inputfold
#SBATCH --ntasks=4
#SBATCH -c 1
#BATCH --mail-type=ALL
module load GCC/6.4.0-2.28
module load OpenMPI/2.1.1-GCC-6.4.0-2.28
#SBATCH --mail-user=oluwole.oyebamiji@ncl.ac.uk
export PATH=$PATH:$HOME/nufeb2/nufeb/code/lammps5Nov16/src
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$HOME/local/lib

#module load intel
#module load OpenMPI/1.8.4-GCC-4.9.3-2.25
#module load OpenMPI/1.10.3-GCC-6.1.0-2.27
#module load GCC/6.4.0-2.28
srun lmp_rocket_gnu -in Input*
