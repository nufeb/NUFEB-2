#################################################NUFEB 2.0

####Design of experiments
R CMD BATCH rnumber.R res1.txt

####Generate 200 design 5 replicates inputscripts for NUFEB 2.0
for num in {1..200}
do
layi=$num
echo $layi | sed s/"num"/$layi/< main.sh >v$num.sh
chmod +x v$num.sh
done
#
for num in {1..200}
do
for fold in {1..5}
do
layi=$fold
echo $layi | sed s/"fold"/$layi/< v$num.sh >v$num.$fold.sh
chmod +x v$num.$fold.sh
done
done

cp v*.sh run
rm v*.sh
###############bash script for submission on Rocket machine
for num in {1..200}
do
for fold in {1..5}
do
sbatch run/v$num.$fold.sh
done
done
######################preprocessing the simulation data
R CMD BATCH prep1d.R res2.txt
##########################train the emulator
R CMD BATCH emulator.R res3.txt
