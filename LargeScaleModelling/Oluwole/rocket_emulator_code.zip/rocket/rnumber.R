#######

nvar=11

npoints=200######nunber of experimental design points

npoints2=5###number of stochastic repetitions

 val=c("30e-3","10e-3","6e-3","6e-3","6e-3","0.00006944444","0.00001158333","0.00001158333","0.63","0.24","0.24")

 vall=as.numeric(val)

 ppara=c("1 sub l","2 o2 l","3 no2 l","4 no3 l","5 nh4 l","het 0.00006944444","aob 0.00001158333","nob 0.00001158333","het 0.63","aob 0.24","nob 0.24")

 dirname=getwd()

 #set.seed(3)

 library(lhs)

 hyper=maximinLHS(npoints,nvar, 2)

 design= matrix(NA,nrow=npoints, ncol=nvar)

 for(j in 1:nvar){

 design[,j]=round(qunif(hyper[,j], min=0.5*vall[j], max=1.5*vall[j]),6)##+-50%

 }

 text <- readLines("atom.in",encoding="UTF-8")

 nrep=npoints

save(design,file=paste(dirname,"design",sep="/"))
id=rep(NA,nvar)
for (i in 1:nvar){
id[i]=grep(ppara[i],text,value=FALSE,fixed=TRUE)
}


 for(rep in 1:nrep){
 for(j in 1:length(val)){
 text[id[j]]=gsub(val[j],design[rep,j],text[id[j]])
 }
 writeLines(text,sub("rep",rep,paste("atom", "rep.in",sep="")))
 text <- readLines("atom.in",encoding="UTF-8")
 }

 #options(scipen=0)

 for( rep in 1: nrep){

 dir.create(sub("rep",rep,paste("input", "rep",sep="")))

 }

 for( rep in 1: nrep){

 file.copy(c(sub("rep",rep,paste("atom","rep.in",sep="")),"Inputscript.lammps"),to=sub("rep",rep,paste("input", "rep",sep="")))

 }



 for( rep in 1: nrep){

 setwd(paste(sub("rep",rep,"inputrep")))

 file.rename(from=sub("rep",rep,paste("atom", "rep.in",sep="")),to=sub("rep",rep,paste("atom", ".in",sep="")))

 setwd("..")

 }



 ###stochasticity

for(fold in 1:npoints){

 source("stoch.R",echo=TRUE)

 }

                     


