#################################TRAIN THE EMULATOR
#####EMULATOR 01/05/2018
#setwd("C:/Users/user/Desktop/And")
load("CON0")
library(abind)
ndes=200
g=rep(NA,ndes)
for(i in 1:ndes){
g[i]=nrow(CON0[[i]])
}
dt=500
gg=ini=list()
for(i in 1:ndes){
ll=nrow(CON0[[i]])
gg[[i]]=(CON0[[i]][-1,-c(10:16)]-CON0[[i]][1:(ll-1),-c(10:16)])/dt##compute rate of change
ini[[i]]=(CON0[[i]][1:(ll-1),-c(10:16)])##compute present nutrient concentrations
}

np=9##number of outputs for emulation
drdt=abind(gg,along=1)
input1=abind(ini,along=1)
s=sample(1:nrow(drdt),2900)# number of training points
input=input1[s,1:np]
output=drdt[s,]
X=input##train inputs
Y=output##train outputs
Xstar=input1[-s,1:np]##validation/left-out
Ystar=drdt[-s,]##validation/left-out
write.table(X,file="X.csv",row.names=FALSE)
write.table(Y,file="Y.csv",row.names=FALSE)
write.table(Xstar,file="Xstar.csv",row.names=FALSE)
write.table(Ystar,file="Ystar.csv",row.names=FALSE)

#################################################
###fitting
library(MASS)
library(emulator)
X=as.matrix(read.table('X.csv',header=TRUE))##training data
Y=as.matrix(read.table('Y.csv',header=TRUE))##training data
##scale input matrix to [0,1]
s1=apply(X,2,min)
s2=apply(X,2,max)
X=scale(X,scale=(s2-s1),center=s1)
############
H<- X#model.matrix(form,data=as.data.frame(X))
k<-dim(Y)[2]
m<-dim(H)[2]
n<-dim(Y)[1]
ninp=dim(X)[2]
id2=ninp+1

mycor=function(X1,X2,betai){
pdf<- diag(betai, nrow = length(betai))
tx1<- t(X1)
tx2 <- t(X2)
R1 <- X1%*%pdf%*%tx1 
R2 <- X2%*%pdf%*%tx2
S1 <- t(as.matrix(diag(R1)))%x%rep(1,nrow(X2))
S2 <- as.matrix(diag(R2))%x%t(rep(1,nrow(X1)))
a1 <- t(tx1)%*%pdf%*%tx2
a2 <- t(tx2)%*%pdf%*%tx1
return(exp(Re(t(a1)+a2-S1-S2)))
}
############## Function giving the log marginal likelihood
theta=runif(ninp+1)#rep(0.05,ninp+1)
likfun2<-function(theta){
R=mycor(X,X,betai=theta[-id2])
A=R+(theta[id2]*diag(1,dim(R)))##add random nugget/noise
Ainv=solve(A)
Omega=t(H)%*%Ainv%*%H
dA=(determinant(A)$modulus[1])###return log ofdeterminant
dOmega=(determinant(Omega)$modulus[1])##return log of determinant
Q1=t(Y)%*%Ainv%*%Y
Q3=t(solve(A,H))
Q4=t(Q3)%*%solve(Omega)%*%Q3
sig=Q1-t(Y)%*%Q4%*%Y
S=determinant(sig)$modulus[1]
-0.5*k*dA-0.5*k*dOmega-.5*(n-m)*S
}
##############
initial_scale=theta
lower=rep(1e-4,length(initial_scale))
upper=3*(apply(X,2,max)-apply(X,2,min))
#opt<-optim(fn=likfun2,par=initial_scale,method="L-BFGS-B",control=list(fnscale= -1,trace=3),lower=lower,upper=upper)
 opt<-optim(fn=likfun2,par=initial_scale,method="L-BFGS-B",control=list(fnscale= -1,trace=3),lower=lower)

save(opt,file=paste(getwd(),"opt",sep="/"))
R=mycor(X,X,betai=opt$par[-id2])#corr matrix for output#2
A=R+(opt$par[id2]*diag(1,dim(R)))
Ainv=solve(A)#chol2inv(chol(A))###
model=list(X=X,Y=Y,theta=opt$par,Ainv=Ainv)
dirname=getwd()
save(model,file=paste(dirname,"model",sep="/"))###spa
#########Validation
pred=function(model,newdata){	
X<- model$X
Y<- model$Y
theta1=model$theta[id2]
theta<- model$theta[-id2]
#form<- model$form
Ainv<- model$Ainv
A=solve(Ainv)
n2<- dim(newdata)[1]
n<- dim(X)[1]
X0<- newdata
#colnames(X0)=model$nam
######model matrix 
H<- X#model.matrix(form,data=as.data.frame(X))
H0<- X0#model.matrix(form,as.data.frame(X0))
A01=mycor(X0,X,betai=theta)###cross correlation
A00=mycor(X0,X0,betai=theta)##test point correlation
Omega=t(H)%*%Ainv%*%H
betahat=solve(t(H)%*%Ainv%*%H)%*%(t(H)%*%Ainv%*%Y)
mu_star=H0%*%betahat+t(A01)%*%Ainv%*%(Y-H%*%betahat)
c_star=A00-(t(A01)%*%Ainv%*%A01)+(((H0-(t(A01)%*%Ainv%*%H))%*%solve(Omega)%*%t(H0-(t(A01)%*%Ainv%*%H))))
Sigma=(t(Y-H%*%betahat)%*%Ainv%*%(Y-H%*%betahat))/(n-m)
svar=list()
for(i in 1:n2){
svar[[i]]=(diag(c_star)[i]*diag(Sigma))
}
K0=abind(svar,along=2)
out=list(mu=mu_star,K=t(K0))
return(out)
}
##########Validation
Xstar=as.matrix(read.table('Xstar.csv',header=TRUE))##test data
X0=scale(Xstar,scale=(ss2-ss1),center=ss1)
Ystar=as.matrix(read.table('Ystar.csv',header=TRUE))##test data
gap=pred(model,newdata=X0)
mu=gap[[1]]
#proportion of variance explained
1-(colSums((Ystar-mu)^2)/colSums((Ystar-colMeans(Ystar))^2))
#diag(cor(Ystar,mu)^2)
#Calculate RMSE
sqrt(colMeans(((Ystar-mu)^2)))
###########training
gap=pred(model,newdata=(X))
mu=gap[[1]]
diag(cor(Y,mu)^2)
#Calculate RMSE
sqrt(colMeans(((Y-mu)^2)))
#proportion of variance explained
1-(colSums((Y-mu)^2)/colSums((Y-colMeans(Y))^2))


##########################################prepare C++ files
iOmega=solve(Omega)
input=(X[1,]*(s2-s1))+s1 ##unscaled 
write.table(X,file="X.txt",row.names=FALSE,col.names=FALSE)
write.table(Y,file="Y.txt",row.names=FALSE,col.names=FALSE)
write.table(Ainv,file="Ainv2.txt",row.names=FALSE,col.names=FALSE)
write.table(iOmega,file="iOmega.txt",row.names=FALSE,col.names=FALSE)
write.table(betahat,file="betahat.txt",row.names=FALSE,col.names=FALSE)
write.table(Sigma,file="Sigma.txt",row.names=FALSE,col.names=FALSE)
write.table(input,file="input.txt",row.names=FALSE,col.names=FALSE)
##########################
