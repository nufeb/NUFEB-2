##########Poisson regression 04-08-2017
#setwd("C:\\Users\\user\\Dropbox\\DLM4\\combine")
setwd("C:\\Users\\user\\Dropbox\\shear\\Shear2_new\\DATA_CODE")
library(MCMCpack)
set.seed(12345)
ntime=20
ll=20
N1=1000#600###burnin
N2=600000##number of mcmc
N3=120
ind=1:2200
ndes=120
ndes2=110
rem=c(1:4)
load("polyset")
library(abind)
id=c(1,4,5,9,12,14)#6,7,8,9,13
nam=c("noe","parentsize","time","height","compeps","mass","shear")

resp=as.matrix(read.csv("Ynoe.csv"))
resp2=as.matrix(read.csv("Ynoe_test.csv"))
input=read.csv("Xnoe.csv")
input2=read.csv("Xnoe_test.csv")
resp=c(resp)
resp2=c(resp2)
###################################################################

quadterms=polySet((ncol(input)),2,2,2)
quad <-formula(paste("resp~", makeScope(quadterms,c(nam[-1]))))
mod1 <- MCMCpoisson(quad,data=input,burnin=N1,mcmc =N2,thin=N3,verbose=1)
path=getwd()
#save(mod1,file=paste(path,"mod1",sep="/"))

###########
cf=summary(mod1)[1]$statistics
coef=stack(colMeans(mod1))[,1]
xnam=colnames(mod1)[-1]
ff=function(newdata){
(form1 <- as.formula(paste("~", paste(xnam, collapse= "+"))))
mm=model.matrix(form1,data.frame(newdata))
y0=round(exp(c(coef %*% t(mm))))
}
X0=as.matrix(cbind(1,input))
x0=as.matrix(cbind(1,input2))
lambda=ff(x0)
res1=res2=list()
##predictions by sampling from Poisson distribution
for(j in 1:length(lambda)){
res1[[j]]=mean(rpois(N1,lambda[j]))
res2[[j]]=sd(rpois(N1,lambda[j]))
}
emu=abind(res1,along=1)
dev=abind(res2,along=1)
#
lambda2=ff(X0)
res1=res2=list()
for(j in 1:length(lambda2)){
res1[[j]]=mean(rpois(N1,lambda2[j]))
res2[[j]]=sd(rpois(N1,lambda2[j]))
}
yhat=abind(res1,along=1)
noee=c(yhat,emu)
#save(noee,file=paste(path,"noee",sep="/"))
mse=sqrt(sum((resp-yhat)^2)/nrow(input))
cor(emu,resp2)^2
lammp=resp2
P=1-(sum((lammp-emu)^2)/sum((lammp- mean(lammp))^2))
RMSE=sqrt(mean((lammp-emu)^2))##RMSE=1.75
ntime=10
emu0=matrix(emu,ntime,ll)
ss=matrix(dev,ntime,ll)
lam=matrix(lammp,ntime,ll)

######horizontal CI
library(plotrix)
dir.create("latest")
dirn=paste(getwd(),"latest",sep="/")
for(k in c(1,2,4,6)){
dirname=file.path(dirn,paste(paste("latest","_"),k,".jpeg",sep=""))
jpeg(file=dirname,quality=100)
emu1=emu0[k,]
lam1=lam[k,]
sss=2*ss[k,]##95%
dev1=emu1+sss
dev2=emu1-sss
y1=min(dev1,dev2,emu1,lam1)
y2 = max(dev1,dev2,emu1,lam1)
y1=y1-1;y2=y2+1
ttime=c(10000,20000,30000,40000,50000,60000,70000,80000,90000,100000,110000,120000,130000,140000,
150000,160000,170000,180000,190000,200000)
F=emu1
U=dev1
L=dev2
plotCI(ttime,F,ui=U,li=L,cex.lab=1.5,cex.axis=1.6,xlab="Time (s)",
cex.main=1.7,slty=3,ylim=c(y1,y2),ylab="Number of event",main="Number of shearing event per 10000s")
lines(ttime,F,ylab="",xlab="",lwd=3)
lines(ttime,lam1,"o",lwd=1,xlab="time (s)",ylab="",xlab="",cex.lab=1.5,cex.axis=1.6,cex.main=1.7,ylim=c(y1,y2))
legend("topright",c("Prediction","Simulation","95% C.I"),
lwd=c(3,1,1),lty=c(1,1,3),bty="0",border="black",cex=1.5,horiz=FALSE)
sh=c(0.25,0.29,0.34,0.21)
ww=paste("Shear rate",paste(sh,"1/s",sep=" "),sep="=")
mtext(paste(ww), 3, line=-2)
dev.off()
}
#################poisson mcmc diagnostics Figure 4a in the manuscript
k=c(2,5,4)
Psi=mod1[,k]
title=c("Shear rates","Biofilm height","EPS composition")#colnames(mod1[])
burn=1000#N1
library(dlm)
par(mfrow=c(3,3))
for(j in 1:3){
par(mar = c(2, 4, 1, 1) + 0.1, cex = 0.6)
hist(Psi[-(1:burn),j],prob=T, main=paste(title[3+j-3]))
lines(density(Psi[-(1:burn),j]),xlab=paste(title[3+j-3]))
ts.plot(ergMean(Psi[-c(1:burn),j]),xlab="iteration",ylab="ErgMean")
ts.plot(Psi[-(1:burn),j], main="",ylab="Traceplots")
}
##################OTHER PLOTS 04-08-2017
#################################################################################END oF 1
noe1=as.matrix(read.csv("noe1.csv"))
noe2=as.matrix(read.csv("noe2.csv"))
time=c(10000,20000,30000,40000,50000,60000,70000,80000,90000,100000,110000,120000,130000,140000,
150000,160000,170000,180000,190000,200000)
id=c(3,10,13,20)
s=c(0.16,0.25,0.28,0.37)
y1=min(noe1+noe2,noe1-noe2)
y2=max(noe1+noe2,noe1-noe2)
coll2=c("red","green","blue","black")
cl=c(gray.colors(1),gray.colors(4),gray.colors(8),gray.colors(12))
coll=line=c(1,2,4,5)

for(k in 1:4){
library(plotrix)
F=round(noe1[k,])
U=F+round(noe2[k,])
L=F-round(noe2[k,])
plotCI(time,F,ui=U,li=L,ylab="Number of events per 10,000 time steps"
,xlab="Time (s)",main="Number of shear events",cex.lab=1.5,cex.axis=1.6,
cex.main=1.7,col=coll2[k],pch=coll[k],lty=coll[k],ylim=c(y1,y2+1),xlim=c(10000,200000))
lines(time,F,ylab="",xlab="",lty=coll[k],col=coll2[k])
par(new=TRUE)
}
legend("topright",paste("shear rate",paste(s,"1/s"),sep="="),
lty=coll,pch=coll,col=coll2,bty="0",border="black",cex=1.6,horiz=FALSE)


##########################no of events over shear
ind=c(15,7,4,20,9,13,3,16,10,11,8,18,6,12,5,17,1,14,2,19)
q1=as.matrix(read.csv("q1.csv"))
q2=as.matrix(read.csv("q2.csv"))
shear=as.matrix((read.csv("shear.csv")))
F=q1[ind]
U=F+(q2[ind])
L=F-(q2[ind])
y1=min(F,U,L)
y2=max(F,U,L)
plotCI(shear[ind],F,ui=U,li=L,ylab="Number of shear events"
,xlab="Shear rate (1/s)",main="Number of shear events",scol=cl[3],slty=1,cex.lab=1.5,cex.axis=1.6,cex.main=1.7,lwd=2,ylim=c(y1,y2))
lines(shear[ind],F,ylab="",xlab="",lty=1,lwd=2)


################volume of detachment vs time
v1=as.matrix(read.csv("v1.csv"))
v2=as.matrix(read.csv("v2.csv"))
y1=min(v1+v2,v1-v2)
y2=max(v1+v2,v1-v2)
for(k in 1:4){
library(plotrix)
F=(v1[k,])
U=F+(v2[k,])
L=F-(v2[k,])
plotCI(time,F,ui=U,li=L,ylab="Detached cluster volume"
,xlab="Time (s)",main="Volume of detached clusters",cex.lab=1.5,cex.axis=1.6,
cex.main=1.7,col=coll2[k],pch=coll[k],lty=coll[k],ylim=c(y1,y2),xlim=c(10000,200000))
lines(time,F,ylab="",xlab="",lty=coll[k],col=coll2[k])
par(new=TRUE)
}
legend("topleft",paste("shear rate",paste(s,"1/s"),sep="="),
lty=coll,pch=coll,col=coll2,bty="0",border="black",cex=1.6,horiz=FALSE)
##############DENSITY PLOTS
####new plot 03-08-2017
dat=t(apply(t(noe1),2,summary))
barplot(dat,beside=TRUE,ylab = 'Number of shear events per 10,000s',main ="Distribution of number of shear events",cex.lab=1.6,cex.main=1.6,legend=paste("shear rate",paste(s,"1/s"),sep="="),args.legend = list(x = "topleft",cex=1.6))
#detached volume
v0=v1
dat=t(apply(t(v0),2,summary))
barplot(dat,beside=TRUE,ylab = 'Detached cluster volume',main ="Distribution of detached cluster volume",cex.lab=1.6,cex.main=1.6,legend=paste("shear rate",paste(s,"1/s"),sep="="),args.legend = list(x = "topleft",cex=1.6))

################total det volume vs shear rates
###method2
voll=as.matrix(read.csv("voll.csv"))
volls=as.matrix(read.csv("volls.csv"))
F=voll
U=F[ind]+(volls[ind])#/time#)
L=F[ind]-(volls[ind])#/time#)
y1=min(F,U,L)
y2=max(F,U,L)
plotCI(shear[ind],F[ind],ui=U,li=L,ylab="Detached cluster"
,xlab="Shear rate (1/s)",main="Total volume of detached clusters",scol=cl[3],cex.lab=1.5,cex.axis=1.6,cex.main=1.7,lwd=2,ylim=c(y1,y2))
lines(shear[ind],F[ind],ylab="",xlab="",lty=1,lwd=2)
###
##############################################################other input plots
r=1#3,5
s1=as.matrix(read.csv("g1.csv"))
s2=as.matrix(read.csv("g2.csv"))
g1=array(s1,c(20,20,6))
g2=array(s2,c(20,20,6))
nam=c("height","roughness","comphet","compeps","nparticle","mass")
id=c(3,10,13,20)
#r=1#r=c(1,3,4,5
p1=g1[ind[id],,r]
p2=g2[ind[id],,r]
y1=min(p1+p2,p1-p2)
y2=max(p1+p2,p1-p2)
for(k in 1:4){
library(plotrix)
F=(p1[k,])
U=F+(p2[k,])
L=F-(p2[k,])
namm=c("Biofilm height (metre)","Surface roughness (metre)","HET composition","EPS composition","No of particles","Biofilm mass (gram)")

plotCI(time,F,ui=U,li=L,ylab=paste(namm[r]),xlab="Time (s)",main=paste(namm[r]),cex.lab=1.5,cex.axis=1.6,
cex.main=1.7,col=coll2[k],lty=coll[k],pch=coll[k],ylim=c(y1-.00001,y2),xlim=c(0,200000))
lines(time,F,col=cl[k],ylab="",xlab="",lty=coll[k])
par(new=TRUE)
}
legend("bottomleft",paste("shear rate",paste(s,"1/s"),sep="="),col=coll2,pch=coll,bty="0",border="black",cex=1.7,horiz=FALSE)

##############REPLOT2
r=6
p1=g1[ind[id],,r]
p2=g2[ind[id],,r]
y1=min(p1+p2,p1-p2)
y2=max(p1+p2,p1-p2)
for(k in 1:4){
library(plotrix)
F=(p1[k,])
U=F+(p2[k,])
L=F-(p2[k,])
namm=c("Biofilm height (metre)","Surface roughness (metre)","HET composition","EPS composition","No of particles","Biofilm mass (gram)")
plotCI(time,F,ui=U,li=L,ylab=paste(namm[r]),xlab="Time (s)",main=paste(namm[r]),cex.lab=1.5,cex.axis=1.6,
cex.main=1.7,col=coll2[k],lty=coll[k],pch=coll[k],ylim=c(y1,y2),xlim=c(0,200000))
lines(time,F,col=cl[k],ylab="",xlab="",lty=coll[k])
par(new=TRUE)
}
legend("bottomleft",paste("shear rate",paste(s,"1/s"),sep="="),col=coll2,pch=coll,bty="0",border="black",cex=1.7,horiz=FALSE)

