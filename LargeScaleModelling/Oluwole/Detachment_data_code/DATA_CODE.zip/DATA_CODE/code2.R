#####################DLM code
##04-08-2017
set.seed(1)
setwd("C:\\Users\\user\\Dropbox\\DLM6")
library(dlm)
library(abind)
load("design")
ntime=20
ll=20
nll=20
ndes=120-2
ndes2=98#100
nvar=5#but quadratic=21
ind1=sample(1:118,98,replace=FALSE)
val=1:(120-2)
ind2=val[-ind1]
rem=c(1:4)
rem2=c(74,92)
load("polyset")
nam=c("noe","volume","kshet","muhet","yhet","shear")
nam1=nam[-2]
namm=c("noe","Size","Volume","Parentsize","time","x","y","z","height","roughness","het","eps","nparticle","mass")         
quadterms=polySet(length(nam1),2,2,2)
quad <-formula(paste("~", makeScope(quadterms,c(nam1))))
#########read in data
X=read.csv("X.csv")
y=read.csv("y.csv")
Xtest=read.csv("Xtest.csv")
ytest=read.csv("ytest.csv")
###########################################################################
psi0 <- 0; tau0 <- 1
shapeY <- 3; rateY <- .01
shapeTheta <- 3; rateTheta <- 1#.01
m <- ncol(y) ; TT=nrow(y)
colnames(X)=nam1
XX=model.matrix(quad,as.data.frame(X))
p=ncol(XX)
mod <- dlm(m0=rep(0,p), C0=diag(p),FF=XX, V=diag(m), GG=diag(p), W=diag(p))
N <- 10000 
N1 <- 1000000
thin=100
Theta <- array(NA, dim=c(N,TT+1,p))
Psi <- matrix(NA, nrow=N, ncol=p)
V <- matrix(NA, nrow=N, ncol=m)
W <- matrix(NA, nrow=N, ncol=p)
# time t_(0) Starting values

phi0 <- rnorm(p,psi0,tau0)
V0 <- 1/rgamma(1,shapeY,rateY)
W0 <- 1/rgamma(1,shapeTheta,rateTheta)
mod$GG=diag(phi0)
mod$V=diag(rep(V0,m))
mod$W=diag(rep(W0,p))
######################################
## Gibbs sampling
for (i in 1:N1)
{
h=i
ind1=i%%thin
n=h[!ind1]
# generate the states by FFBS
mod2 <- dlmFilter(y, mod, simplify=TRUE)
theta <- dlmBSample(mod2)
Theta[n/thin,,] <- theta
# generate the W_j
thetac <- theta[-1,] - t(mod$GG %*% t(theta[-(TT+1),]))
SStheta=apply((thetac)^2, 2,sum)
phiTheta=rgamma(p, shape=shapeTheta+TT/2, rate=rateTheta+SStheta/2)
W[n/thin,] <- 1/phiTheta
mod$W <- diag(1/phiTheta) #diag(W[n/100,])
# generate the V_i
yc <- y -t(mod$FF %*% t(theta[-1,]))
SSy=apply((yc)^2, 2,sum)
V[n/thin,] <- phiy <- 1/rgamma(m, shape=shapeY+TT/2, rate=rateY+SSy/2)
mod$V <- diag(phiy) # diag(V[n/100,])
# generate the AR parameters psi_1, psi_2, psi_3
psi.AR=rep(NA,p)
for (j in 1:p)
{tau= 1/((1/tau0) + phiTheta[j] * crossprod(theta[-(TT+1),j]))
psi=tau * (phiTheta[j] * t(theta[-(TT+1),j])  %*% theta[-1,j] + psi0/tau0)
psi.AR[j]=rnorm(1, psi, sd=tau^.5)
}
Psi[n/thin,] <- psi.AR
mod$GG <-diag(psi.AR)
print(paste("iteration",i,sep=" "))
}
burn <- 5000

title=c("Intercept","Shear force","Yhet","Muhet","Kshet","No of shear events")
#title=c("No of shear events","KsHET","MuHET","YHET","shear_force")
par(mfrow=c(3,3))
#for (j in 1:p){
for (j in c(2,3,5)){
title=c("No of shear events","KsHET","MuHET","YHET","Shear force")
hist(Psi[-(1:burn),j],xlab="", prob=T,main=paste(title[j]))
lines(density(Psi[-(1:burn),j]),xlab=sub("j",j,paste("Psi","j",sep="_")))
plot.ts(ergMean(Psi[-c(1:burn),j]),xlab="iterations",ylab="ErgMean",cex.lab=1.3,cex.axis=1.3)
plot.ts(Psi[-(1:burn), j],xlab="iterations", ylab="Traceplots",cex.lab=1.3,cex.axis=1.3)
}
#### for V
#randomly selected 3 points
par(mfrow=c(3,3))
tit=c("Phi_V_1","Phi_V_2","Phi_V_3")
for (j in c(1,2,3)){
#par(mar = c(2, 4, 1, 1) + 0.1, cex = 0.6)
hist(V[-(1:burn),j+8],xlab="",prob=T, main=paste(tit[j]))
lines(density(V[-(1:burn),j+8]),xlab=sub("j",j,paste("Phi_V","j",sep="_")))
ts.plot(ergMean(V[-c(1:burn),j+8]), xlab="iterations",ylab="ErgMean")
ts.plot(V[-(1:burn), j+8],xlab="iterations", ylab="Traceplots")
}
####W
par(mfrow=c(3,3))
for (j in c(2,3,5)){
hist(W[-(1:burn),j],xlab="",prob=T, main=paste(title[j]))
lines(density(W[-(1:burn),j]),xlab=sub("j",j,paste("Phi_W","j",sep="_")))
ts.plot(ergMean(W[-c(1:burn),j]), xlab="iterations",ylab="ErgMean")
ts.plot(W[-(1:burn), j],xlab="iterations", ylab="Traceplots")
}
####Theta
par(mfrow=c(3,3))
tt=1
for (j in c(2,3,5)){
hist(Theta[-(1:burn),tt,j],xlab="",prob=T,main=paste(title[j]))
lines(density(Theta[-(1:burn),tt,j]),xlab=sub("j",j,paste("Theta","j",sep="_")))
ts.plot(ergMean(Theta[-c(1:burn),tt,j]),xlab="iterations",ylab="ErgMean")
ts.plot(Theta[-(1:burn),tt,j],xlab="iterations", ylab="Traceplots")
}
#########################################
path=getwd()

save(W,file=paste(path,"W",sep="/"))
save(V,file=paste(path,"V",sep="/"))
save(Psi,file=paste(path,"Psi",sep="/"))
save(Theta,file=paste(path,"Theta",sep="/"))
save(mod2,file=paste(path,"mod2",sep="/"))

nam1=c("noe","kshet","muhet","yhet","shear")
GG=diag(round(mcmcMean(Psi[-(1:burn),]),4)[1,])
v0=(round(mcmcMean(V[-(1:burn),]),4)[1,])
w0=(round(mcmcMean(W[-(1:burn),]),4)[1,])
a=apply(Theta[-c(1:burn),,], c(2,3), mean)[-1,]
v <- (dlmSvd2var(mod2$U.C,mod2$D.C))

#ind2=1   3   6  10  13  18  28  30  47  54  62  71  75  82  84  89  91 115 116 117
###method1
M=M1=M2=matrix(NA,nrow=ntime,ndes2)
for(i in 1:ntime){
xx=X
colnames(xx)=nam1
xx=model.matrix(quad,as.data.frame(xx))
M[i,] <- t(xx %*%t(a[i,,drop=FALSE]))
}
diag(cor(y,M)^2)
res <- (y-M)^2
S <- rowSums(res) / (m-p)
#cross
M=M1=M2=matrix(NA,nrow=ntime,ntime)
for(i in 1:ntime){
xx=Xtest[,]
colnames(xx)=nam1
xx=model.matrix(quad,as.data.frame(xx))
M[i,] <- t(xx %*%t(a[i,,drop=FALSE]))
}
diag(cor(ytest,M)^2)
dirname=path=getwd()
save(M,file=paste(path,"M",sep="/"))
save(S,file=paste(path,"S",sep="/"))

shear=c(0.30,0.17,0.27,0.17,0.17,0.15,0.32,0.31,0.23,0.32,0.21,0.28,0.21,0.37,0.25,0.33,0.15,0.13,0.21,0.32)
ttime=c(10000,20000,30000,40000,50000,60000,70000,80000,90000,100000,110000,120000,130000,140000,
150000,160000,170000,180000,190000,200000)
library(plotrix)
dir.create("plot_method1")
dirn=paste(getwd(),"plot_method1",sep="/")
for(k in 1:ntime){
dirname=file.path(dirn,paste(paste("plot_method1","_"),k,".jpeg",sep=""))
jpeg(file=dirname,quality=120)
F=M[,k]
lammp=ytest[,k]
sd=S[k]
U=F+2*sd
L=F-2*sd
ylim=y=range(U,F,L,lammp)
plotCI(ttime,lammp,ui=U,li=L,cex.lab=1.5,cex.axis=1.6,xlab="Time (s)",
cex.main=1.7,slty=3,ylim=ylim,ylab="log(detached cluster)",main="Volume of detached clusters")
lines(ttime,F,ylab="",xlab="",lwd=3)
lines(ttime,lammp,"o",lwd=1,xlab="time (s)",ylab="",xlab="",cex.lab=1.5,cex.axis=1.6,cex.main=1.7)
legend("topright",c("Prediction","Simulation","95% C.I"),
lwd=c(3,1,1),lty=c(1,1,3),bty="0",border="black",cex=1.5,horiz=FALSE)
sh=shear[k]
ww=paste("Shear rate",paste(sh,"1/s",sep=" "),sep="=")
mtext(paste(ww), 3, line=-1)
dev.off()
}
#####################method2
C=v <- (dlmSvd2var(mod2$U.C,mod2$D.C))
RR <- (dlmSvd2var(mod2$U.R,mod2$D.R))
yp=M2=S2=matrix(NA,nrow=ntime,ncol=nll)
colnames(Xtest)=nam1

for(k in 1:nll){###20 left out points
test=ytest[,k]##test data
newdata=Xtest
Q=mu_hat=sd_hat=yt=rep(NA,nrow=ntime)
colnames(newdata)=nam1
newdata=model.matrix(quad,as.data.frame(newdata))
for(j in 1:ntime){
yt[j]=newdata[1,]%*%a[j,]
Q[j]=(newdata[1,,drop=FALSE] %*% (RR[[j]]) %*% t(newdata[1,,drop=FALSE])) + mean(v0)
qt=sqrt(Q)
gg=rnorm(burn,yt[j],qt[j])
mu_hat[j]=mean(gg)
sd_hat[j]=sd(gg)
}
M2[,k]=mu_hat
S2[,k]=sd_hat
yp[,k]=yt
}

diag(cor(M2,ytest))^2
dirname=path=getwd()
save(M2,file=paste(path,"M2",sep="/"))
save(S2,file=paste(path,"S2",sep="/"))

shear=c(0.30,0.17,0.27,0.17,0.17,0.15,0.32,0.31,0.23,0.32,0.21,0.28,0.21,0.37,0.25,0.33,0.15,0.13,0.21,0.32)
ttime=c(10000,20000,30000,40000,50000,60000,70000,80000,90000,100000,110000,120000,130000,140000,
150000,160000,170000,180000,190000,200000)
library(plotrix)
dir.create("plot_method2b")
dirn=paste(getwd(),"plot_method2b",sep="/")
for(k in 1:ntime){
dirname=file.path(dirn,paste(paste("plot_method2b","_"),k,".jpeg",sep=""))
jpeg(file=dirname,quality=120)
F=M2[,k]
lammp=ytest[,k]
sd=S2[,k]
U=F+sd
L=F-sd
ylim=y=range(U,F,L,lammp)
plotCI(ttime,lammp,ui=U,li=L,cex.lab=1.5,cex.axis=1.6,xlab="Time (s)",
cex.main=1.7,slty=3,ylim=ylim,ylab="log(detached cluster)",main="Volume of detached clusters")
lines(ttime,F,ylab="",xlab="",lwd=3)
lines(ttime,lammp,"o",lwd=1,xlab="time (s)",ylab="",xlab="",cex.lab=1.5,cex.axis=1.6,cex.main=1.7)
legend("topright",c("Prediction","Simulation","95% C.I"),
lwd=c(3,1,1),lty=c(1,1,3),bty="0",border="black",cex=1.5,horiz=FALSE)
sh=shear[k]
ww=paste("Shear rate",paste(sh,"1/s",sep=" "),sep="=")
mtext(paste(ww), 3, line=-1)
dev.off()
}
###########################

########################SENSITIVITY 13-07-2017
pred=function(xx,a,tt){
colnames(xx)=nam1
xx=model.matrix(quad,as.data.frame(xx))
M <- t(xx %*%t(a[tt,,drop=FALSE]))
return(c(M))
}
p=5
library(sensitivity)

n <- 5000
X1=X2=matrix(NA,n,p)
for(i in 1:p){
X1[,i] <- runif(n,min=0,max=1)
X2[,i] <- runif(n,min=0,max=1)
}
colnames(X1)=colnames(X2)=nam1
sens=list()
for(tt in 1:20){
x1 <- soboljansen(model = pred, X1, X2, nboot = 100,a=a,tt=tt)
x2<- sobolEff(model = pred,X1, X2,a=a,tt=tt)
sens[[tt]]=x2
}
ss=list()
for(i in 1:20){
ss[[i]]=sens[[i]]$S$original
}
dat=abind(ss,along=0)
save(sens,file=paste(path,"sens",sep="/"))
##########plot
dat[which(dat<0)]=0
datt=dat/rowSums(dat)
#par(mar=c(5.1,4.5,1.9,.5)+1.9)
coll=c("red","green","blue","grey","pink")
#coll=gray.colors(50)
#coll=coll[c(1,10,20,40,50)]
nam1=c("Number of events","Kshet","Muhet","Yhet","Shear rates")
#xvals=barplot(t(datt),xlab="Time (s)",ylab="Sensitivity indices",main="Sensitivity analysis",ylim=c(0,1.7),offset=0,cex.lab=1.5,col=c("red","purple","green","blue","grey"),density=c(40,60,90,120,150),cex.main=1.8,space=0.3,angle=c(45,90,135,150,210),cex.axis=1.5,cex.names=1.5,args.legend=list(x=c(4,8),y=c(1.1,1.7),bty="n",cex=2),legend=paste(nam1),names.arg=1:20)
xvals=barplot(t(datt),xlab="Time (s)",col=coll,ylab="Sensitivity indices",main="Sensitivity analysis",pch=1:5,ylim=c(0,2.0),offset=0,cex.lab=1.5,density=c(40,80,120,160,200),cex.main=1.8,space=0.3,angle=c(30,60,90,120,150),cex.axis=1.5,cex.names=1.5,args.legend=list(x=c(4,8),y=c(1.2,2.0),bty="n",cex=1.8),legend=paste(nam1))
text(xvals,par("usr")[3]-.01,srt=45,adj=1,labels=ttime,xpd=TRUE,cex=1.3)
