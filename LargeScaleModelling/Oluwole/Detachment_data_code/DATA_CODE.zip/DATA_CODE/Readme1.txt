Title: A surrogate-based approach to modelling the impact of hydrodynamic shear stress on biofilm deformation
O.K. Oyebamiji, D.J. Wilkinson, P.G. Jayathilake, T.P. Curtis, S.P. Rushton, B. Li, B. Bridgens, P. Zuliani

This folder contains data and code to reproduce results in the manuscripts.
(a) code1.R - R functions for fitting Poisson model and performing crossvalidation for number of events
using MCMCpack library in R
(i) Xnoe.csv and Ynoe.csv - training data for fitting Posson model to number of events
(i) Xnoe_test.csv and Ynoe_test.csv - test data for number of events
(iii) noe1.csv, noe2.csv, v1.csv, v2.csv, voll.csv, volls.csv, q1.csv, q2.csv and shear.csv - data for plotting Figure 2 in the manuscript 
(iv) g1.csv, g2.csv - data for plotting Figure 3 in the manuscript 


(a) code2.R - R functions for fitting dynamic linear models and performing crossvalidation for volume of
 detached clusters using DLM library in R
(i) X.csv and y.csv - training data for fitting DLM model
(ii) Xtest.csv and ytest.csv - test data for fitting DLM model

NOTE: Figures 1 in the manuscripts is made outside R.
###################################################################
Dr. O.K. Oyebamiji
School of Mathematics & Statistics
Newcastle University
Newcastle upon Tyne
NE1 7RU
UK
E-mail: wolemi2@yahoo.com; Oluwole.Oyebamiji@ncl.ac.uk