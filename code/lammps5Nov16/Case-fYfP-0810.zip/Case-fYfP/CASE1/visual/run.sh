#!/bin/bash
# Matlab povray script

matlab -nodisplay -nosplash -nodesktop -r "run('visual200cubic.m');exit;"
